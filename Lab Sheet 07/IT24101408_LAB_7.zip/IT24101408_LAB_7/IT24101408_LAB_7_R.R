#Exercies 
setwd("C:\\Users\\hp\\Desktop\\IT24101408_LAB_7")

#question 1
# Uniform distribution probability
punif(25, min=0, max=40) - punif(10, min=0, max=40)

#question 2
pexp(2, rate = 1/3)

#question 3 part 1
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

#question 3 part 2
qnorm(0.95, mean = 100, sd = 15)

